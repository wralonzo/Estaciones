<?php
$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);
/*if(conexion_connect_errno){
	die ("fallo la conexion:(".$conexion ->mysqli_conect_errno()")".$conexion ->mysqli_conect_error())
}*/

/////consulta
$equipo="SELECT * FROM equipo order by marca";
$resequipo=$conexion->query($equipo);
?>  

<html>
	<head>
		<title>EQUIPO</title>
		<link rel="stylesheet" type="text/css" href="css/table.css"/>
	</head>
	<h1>EQUIPO</h1>

	<section>


		<br><button name="nuevo" class="button button3" onclick="window.location='http://localhost/proyectosumg/Estaciones/Formulario/equipo.html'"/>Nuevo Registro</button>
		
		<form  method="POST" action="../Controladores/buscarEquipo.php">
			<label>Buscar</label>
			<input type="text" name="txtBuscar" placeholder="Ingrese su busqueda" required=""></input>

			<button name="Buscar" class="button button2">Buscar</button>
		</form>
	
		<form method="POST" action="../Controladores/eliminarEquipo.php">
		<table class= "table">
			<tr>
				<th>Marca</th>
				<th>Serie</th>
				<th>Tipo</th>
				<th>#Oper</th>
				<th>Marca</th>
				<th>Serie</th>
				<th>Tipo</th>
				<th>#Oper</th>
				<th>Pro_Fase</th>
				<th>Pro_Curva</th>
				<th>Cur_Fase</th>
				<th>Cur_Neutro</th>
				<th>Eliminar</th>
				<th>modificar</th>
				
				<th>Registrar</th>

			</tr>
			<?php
				while ($registroempleado = $resequipo->fetch_array(MYSQLI_BOTH))
				{
					echo '<tr>
							<td>'.$registroempleado['marca'].'</td>
							<td>'.$registroempleado['seriecotrol'].'</td>
							<td>'.$registroempleado['tipocontrol'].'</td>
							<td>'.$registroempleado['marcacuba'].'</td>
							<td>'.$registroempleado['seriecuba'].'</td>
							<td>'.$registroempleado['tipocuba'].'</td>
							<td>'.$registroempleado['noperaciones'].'</td>
							<td>'.$registroempleado['nopercuba'].'</td>
							<td>'.$registroempleado['protfase'].'</td>
							<td>'.$registroempleado['protnuetro'].'</td>
							<td>'.$registroempleado['curvafase'].'</td>
							<td>'.$registroempleado['curvaneutro'].'</td>
							<td><input type="checkbox" name="eliminar[]" value="'.$registroempleado['id'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registroempleado['id'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
						</tr>';
				}
			?>
		</table>
		</form>
	</section>
</html>