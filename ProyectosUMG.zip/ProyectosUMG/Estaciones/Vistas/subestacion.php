<?php
$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);
/*if(conexion_connect_errno){
	die ("fallo la conexion:(".$conexion ->mysqli_conect_errno()")".$conexion ->mysqli_conect_error())
}*/

/////consulta
$subestacion="SELECT * FROM subestacion order by codigo";
$resubestacion=$conexion->query($subestacion);
?>  

<html>
	<head>
		<title>SUBESTACION</title>
		<link rel="stylesheet" type="text/css" href="css/table.css"/>
	</head>
	<h1>SUBESTACION</h1>

	<section>
		
		<br><button name="nuevo" class="button button3" onclick="window.location='http://localhost/proyectosumg/Estaciones/formulario/subestacion.html'"/>Nuevo Registro</button>
		
		<form  method="POST" action="../Controladores/buscarSubestacion.php">
			<label>Buscar</label>
			<input type="text" name="txtBuscar" placeholder="Ingrese codigo" required=""></input>

			<button name="Buscar" class="button button2">Buscar</button>
		</form>
			
						
		<form method="POST" action="../Controladores/eliminarSubestacion.php">



		<table class= "table">
			<tr>
				<th>ID</th>
				<th>Nombre</th>
				<th>Ubicacion</th>
				<th>Etrada</th>
				<th>Salida</th>
				<th>Potencia</th>
				<th>Eliminar</th>
				<th>Modificar</th>
				<th>Registrar</th>
				
			</tr>
			<?php
				while ($registrosalida = $resubestacion->fetch_array(MYSQLI_BOTH))
				{
					echo '<tr>
							
							<td>'.$registrosalida['codigo'].'</td>
							<td>'.$registrosalida['nombre'].'</td>
							<td>'.$registrosalida['ubicacion'].'</td>
							<td>'.$registrosalida['entrada'].'</td>
							<td>'.$registrosalida['salida'].'</td>
							<td>'.$registrosalida['potencia'].'</td>
							<td><input type="checkbox" name="eliminar[]" value="'.$registrosalida['id'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registrosalida['id'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
						</tr>';
				}
			?>
		</table>
	</section>
</html>