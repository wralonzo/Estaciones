<?php
$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);
/*if(conexion_connect_errno){
	die ("fallo la conexion:(".$conexion ->mysqli_conect_errno()")".$conexion ->mysqli_conect_error())
}*/

/////consulta
$salida="SELECT * FROM salida";
$resalida=$conexion->query($salida);
?>  

<html>
	<head>
		<title>SALIDA</title>
		<link rel="stylesheet" type="text/css" href="css/table.css"/>
	</head>
	<h1>SALIDA</h1>



	<section>
		
		<br><button name="nuevo" class="button button3" onclick="window.location='http://localhost/proyectosumg/Estaciones/formulario/salida.html'"/>Nuevo Registro</button>
		
		<form  method="POST" action="../Controladores/buscarSalida.php">
			<label>Buscar</label>
			<input type="text" name="txtBuscar" placeholder="Ingrese DPI" required=""></input>

			<button name="Buscar" class="button button2">Buscar</button>
		</form>
			
						
		<form method="POST" action="../Controladores/eliminarSalida.php">

		<table class= "table">
			<tr>
				<th>ID</th>
				<th>Nombre</th>
				<th>Tipo</th>
				<th>Ubicacion</th>
				<th>Tension</th>
				<th>Eliminar</th>
				<th>Modificar</th>
				<th>Registrar</th>
			</tr>
			<?php
				while ($registroempleado = $resalida->fetch_array(MYSQLI_BOTH))
				{
					echo '<tr>
							<td>'.$registroempleado['codigo'].'</td>
							<td>'.$registroempleado['nombre'].'</td>
							<td>'.$registroempleado['tipo'].'</td>
							<td>'.$registroempleado['ubicacion'].'</td>
							<td>'.$registroempleado['tension'].'</td>
							<td><input type="checkbox" name="eliminar[]" value="'.$registroempleado['id'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registroempleado['id'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
						</tr>';
				}
			?>
		</table>
	</section>
</html>