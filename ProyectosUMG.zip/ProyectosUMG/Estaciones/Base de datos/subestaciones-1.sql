CREATE TABLE `empleado` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `direccion` varchar(300) COLLATE utf8mb4_spanish_ci NOT NULL,
  `correo` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `dpi` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecnac` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`codigo`, `nombre`, `apellido`, `direccion`, `correo`, `dpi`, `fecnac`) VALUES
(12, 'Willian', 'Roberto', 'San jose', '1@GMAIL', '45445', '0005-05-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipo`
--

CREATE TABLE `equipo` (
  `id` int(11) NOT NULL,
  `marca` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `seriecotrol` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tipocontrol` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `marcacuba` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `seriecuba` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tipocuba` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `noperaciones` int(11) NOT NULL,
  `nopercuba` int(11) NOT NULL,
  `protfase` decimal(10,0) NOT NULL,
  `protnuetro` decimal(10,0) NOT NULL,
  `curvafase` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `curvaneutro` text COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `usuario` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(10) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salida`
--

CREATE TABLE `salida` (
  `id` int(11) NOT NULL,
  `codigo` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tipo` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tension` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subestacion`
--

CREATE TABLE `subestacion` (
  `id` int(11) NOT NULL,
  `codigo` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `ubicacion` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `entrada` decimal(10,0) NOT NULL,
  `salida` decimal(10,0) NOT NULL,
  `potencia` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `equipo`
--
ALTER TABLE `equipo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `salida`
--
ALTER TABLE `salida`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `subestacion`
--
ALTER TABLE `subestacion`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `equipo`
--
ALTER TABLE `equipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `salida`
--
ALTER TABLE `salida`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `subestacion`
--
ALTER TABLE `subestacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
