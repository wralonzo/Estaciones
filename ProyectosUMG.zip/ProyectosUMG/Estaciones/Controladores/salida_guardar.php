<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion = new mysqli($host, $usuario, $contraseña, $base);
	//recuperar las variables del formulario
	$id1="null";
	$id=$_POST['codigo'];
	$name=$_POST['nombre'];
	$tipo=$_POST['tipo'];
	$ubicacion=$_POST['ubicacion'];
	$tension=$_POST['tension'];
	
	//hacemos la sentencia sql


	$sql="INSERT INTO salida VALUES ('$id1', '$id', '$name', '$tipo',  '$ubicacion', '$tension')";

	$ejecutar=$conexion->query($sql);
	//$ejecutar = query($sql,$conexion);


	
	header("Location: http://localhost/proyectosumg/Estaciones/vistas/salida.php");

?>
