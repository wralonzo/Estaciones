<?php
	$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);;

	$equipo="SELECT * FROM subestacion order by codigo";
	$ressub=$conexion->query($equipo);
	$buscar = $_POST['txtBuscar'];
	echo "<h1>Busqueda de SubEstaciones</h1>";
		?>
					<!DOCTYPE html>
					    <html>
					    		<head>
					    			<title></title>
					    			<link rel="stylesheet" type="text/css" href="../Vistas/css/table.css"/>
					    		</head>
					    		<body>					    		
					    	<section>					    			
					    			<button class="button button6" onclick="window.location='http://localhost/proyectosumg/Estaciones/Vistas/subestacion.php'">Volver</button>	<br><br>
					    			<form action="../Controladores/eliminarSubestacion.php" method="POST">
					    		<table class= "table" border="3" >
									<tr>
										<th>ID</th>
										<th>Nombre</th>
										<th>Ubicacion</th>
										<th>Etrada</th>
										<th>Salida</th>
										<th>Potencia</th>
										<th>Eliminar</th>
										<th>Modificar</th>
										<th>Registrar</th>
									<tr>

	<?php	
	while ($registrosalida = $ressub->fetch_array(MYSQLI_BOTH))
				{
					 $codigo=$registrosalida[1];
					 

					
					if($codigo === $buscar) {

						echo '<tr>
							<td>'.$registrosalida['codigo'].'</td>
							<td>'.$registrosalida['nombre'].'</td>
							<td>'.$registrosalida['ubicacion'].'</td>
							<td>'.$registrosalida['entrada'].'</td>
							<td>'.$registrosalida['salida'].'</td>
							<td>'.$registrosalida['potencia'].'</td>
							<td><input type="checkbox" name="eliminar[]" value="'.$registrosalida['codigo'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registrosalida['codigo'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
						</tr>';


					}
						


			    
				}
			echo "</form></table> </section>";



			    
			 
			





?>