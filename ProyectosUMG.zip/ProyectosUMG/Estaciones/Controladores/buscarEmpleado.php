<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion = new mysqli($host, $usuario, $contraseña, $base);


	$empleado="SELECT * FROM empleado order by codigo";

	$resempleado=$conexion->query($empleado);
	
	$buscar = $_POST['txtBuscar'];
	echo "<h1>Busqueda de Empleados</h1>";
	
	
	?>

	<!DOCTYPE html>
					    <html>
					    		<head>
					    			<title></title>
					    			<link rel="stylesheet" type="text/css" href="../Vistas/css/table.css"/>
					    		</head>
					    		<body>					    		
					    	<section>					    			
					    			<button class="button button6" onclick="window.location='http://localhost/proyectosumg/Estaciones/Vistas/empleado.php'">Volver</button>	<br><br>
	<form method="POST" action="../Controladores/eliminar.php">
			
			<table class= "table" border="3" >
				<tr>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>Direccion</th>
					<th>Correo</th>
					<th>Dpi</th>
					<th>Fecha de nacimiento</th>
					<th>Eliminar</th>
					<th>Modificar</th>
					<th>Registrar</th>
				</tr>
				<?php 
							
				
					while ($registroempleado = $resempleado->fetch_array(MYSQLI_BOTH))
					{
						$dpi = $registroempleado['5'];


						if($dpi === $buscar) {
							echo '<tr>								
								<td>'.$registroempleado['nombre'].'</td>
								<td>'.$registroempleado['apellido'].'</td>
								<td>'.$registroempleado['direccion'].'</td>
								<td>'.$registroempleado['correo'].'</td>
								<td>'.$registroempleado['dpi'].'</td>
								<td>'.$registroempleado['fecnac'].'</td>
								<td><input type="checkbox" name="eliminar[]" value="'.$registroempleado['codigo'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registroempleado['codigo'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
							</tr>'; 

					}
				}
					echo "</form></table> </section>";


?>