<?php
	$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);
/*if(conexion_connect_errno){
	die ("fallo la conexion:(".$conexion ->mysqli_conect_errno()")".$conexion ->mysqli_conect_error())
}*/

	
	//recumerar las variables del formulario
	$id1="null";
	$id=$_POST['codigo'];
	$nombre=$_POST['nombre'];
	$ubicacion=$_POST['ubicacion'];
	$entrada=$_POST['entrada'];
	$salida=$_POST['salida'];
	$potenciainst=$_POST['potencial'];
	

	$sql="INSERT INTO subestacion VALUES ('$id1', '$id', '$nombre', '$ubicacion', '$entrada', '$salida', '$potenciainst')";
	$ejecutar=$conexion->query($sql);
	//$ejecutar = query($sql,$conexion);


	
	header("Location: http://localhost/proyectosumg/Estaciones/vistas/subestacion.php");
?>