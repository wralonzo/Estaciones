<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>


<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion =mysql_connect($host, $usuario, $contraseña);
	mysql_select_db($base, $conexion);

	 $consulta = mysql_query("SELECT * FROM salida", $conexion) OR die ("No se pudo ejecutar la consulta1");


	if(isset($_POST['eliminar'])){ 

	$el = $_POST['eliminar'];

	try {
		foreach($el as $id){
					mysql_query("delete from salida where id=".$id."", $conexion);
					header("Location: http://localhost/proyectosumg/Estaciones/vistas/salida.php");

							
		
		}
		}
		 catch (Exception $e) {
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/salida.php");
	}
	}
	


	if(isset($_POST['modificar'])){
		$mod = $_POST['modificar'];
      //  $query = "UPDATE empleado set nombre='hola' WHERE codigo=".$_POST['modificar'];
        //echo $query;
        foreach($mod as $id2){

        	while ($fila = mysql_fetch_row($consulta)) {
        		$identidicado=$fila['0'];
        		$id3=$fila['1'];
				$nombre=$fila['2'];
				$tipo=$fila['3'];
				$ubicacion=$fila['4'];
				$tencion=$fila['5'];
				
				

				    if ($id2 ===$identidicado) {
				    	
				    	?>

				    	<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>salida</title>
		<link rel="stylesheet" type="text/css" href="../Formulario/css/estilo.css"/>
	</head>

	<body>
		<div class="form">
			<form action="../Controladores/modificarSalida.php" method="POST">
				<h1>Modificar Salida</h1>
				<label form="codigo"></label>
				<input type="text" name="id" placeholder="codigo salida"  value="<?php echo $identidicado;  ?>">
				<label form="codigo"></label>
				<input type="text" name="codigo" placeholder="codigo salida"  value="<?php echo $id3;  ?>">

				<label form="nombre"></label>
				<input type="text" name="nombre" placeholder="nombre salida"  value="<?php echo $nombre;  ?>">

				<label form="tipo"></label>
				<input type="text" name="tipo" placeholder="tipo"  value="<?php echo $tipo;  ?>">

				<label form="ubicacion"></label>
				<input type="text" name="ubicacion" placeholder="ubicacion geografica"  value="<?php echo $ubicacion;  ?>">

				<h4>Tension</h4>
				<label for="tension"></label>
				<select id="tension" name="tension">
					<option value="" selected="selected"><?php echo $tencion;  ?></option>
					<option value="1.5"> 1.5 kwts</option>
					<option value="2.5"> 2.5 kwts</option>
					<option value="5.5"> 5.5 kwts</option>
				</select>
				<br><br><br><br>
				<button>Enviar</button>
			</form>
		</div>
	</body>
</html>
				    		

				    	<?php

					}

				
			}
        
    }
    }			
?>