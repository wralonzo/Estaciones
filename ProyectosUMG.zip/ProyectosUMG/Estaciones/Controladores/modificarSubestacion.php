
<?php
$conexion = mysql_connect("localhost" , "root" , "");

    if (!$conexion) {
        echo 'error';
    }
    mysql_select_db("subestaciones",$conexion);

    $id1=$_POST['id'];
    $id=$_POST['codigo'];
	$nombre=$_POST['nombre'];
	$ubicacion=$_POST['ubicacion'];
	$entrada=$_POST['entrada'];
	$salida=$_POST['salida'];
	$potenciainst=$_POST['potenciai'];
	//hacemos la sentencia sql
	//$sql = "UPDATE subestacion set nombre='$nombre', ubicacion='$ubicacion', entrada='$entrada', salida='$salida', potencia='$potenciainst' WHERE codigo='$id' ";

	$sql = "UPDATE subestacion set codigo='$id', nombre='$nombre', ubicacion='$ubicacion', entrada='$entrada', salida='$salida', potencia='$potenciainst' WHERE id='$id1' ";
	$ejecutar = mysql_query($sql, $conexion);

	//ejecutar sentencia
	
	if (!$ejecutar) {
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/subestacion.php");
	}

	else{
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/subestacion.php");
	}
	//verificar ejecucion
	



?>