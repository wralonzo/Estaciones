<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>


<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion =mysql_connect($host, $usuario, $contraseña);
	mysql_select_db($base, $conexion);

	 $consulta = mysql_query("SELECT * FROM subestacion", $conexion) OR die ("No se pudo ejecutar la consulta1");


	if(isset($_POST['eliminar'])){ 

	$el = $_POST['eliminar'];

	try {
		foreach($el as $id){
					mysql_query("delete from subestacion where id=".$id."", $conexion);
					header("Location: http://localhost/proyectosumg/Estaciones/vistas/subestacion.php");

							
		
		}
		}
		 catch (Exception $e) {
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/subestacion.php");
	}
	}
	


	if(isset($_POST['modificar'])){
		$mod = $_POST['modificar'];
      //  $query = "UPDATE empleado set nombre='hola' WHERE codigo=".$_POST['modificar'];
        //echo $query;
        foreach($mod as $id2){

        	while ($fila = mysql_fetch_row($consulta)) {
        		$id1=$fila['0'];
        		$id3=$fila['1'];
				$nombre=$fila['2'];
				$ubicacion=$fila['3'];
				$entrada=$fila['4'];
				$salida=$fila['5'];
				$potenciainst=$fila['6'];
				

				    if ($id2 ===$id3) {
				    	
				    	?>

				    	<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>SUBESTACION</title>
		<link rel="stylesheet" type="text/css" href="../Formulario/css/estilo.css"/>
	</head>

	<body>
		<div class="form">
			<form action="../Controladores/modificarSubestacion.php" method="POST">
				<h1>Modificar subestaciones</h1>
				<label form="codigo"></label>
				<input type="text" name="id" placeholder="codigo subestacion" value="<?php echo $id1;  ?>">
				

				<label form="codigo"></label>
				<input type="text" name="codigo" placeholder="codigo subestacion" value="<?php echo $id3;  ?>">
				
				<label form="nombre"></label>
				<input type="text" name="nombre" placeholder="nombre subestacion" value="<?php echo $nombre;  ?>">
				
				<label form="ubicacion"></label>
				<input type="text" name="ubicacion" placeholder="ubicacion geografica" value="<?php echo $ubicacion;  ?>">

				<h3>Entrada &nbsp &nbsp &nbsp &nbsp Salida</h1>
				<label for="entrada"></label>
				<select id="entrada" name="entrada">
					<option value="" selected="selected"><?php echo $entrada;  ?></option>
					<option value="1.5"> 1.5 kwts</option>
					<option value="2.5"> 2.5 kwts</option>
					<option value="5.5"> 5.5 kwts</option>
				</select>

				<label for="salida"></label>
				<select id="salida" name="salida">
					<option value="" selected="selected"><?php echo $salida;  ?></option>
					<option value="1.5"> 1.5 kwts</option>
					<option value="2.5"> 2.5 kwts</option>
					<option value="5.5"> 5.5 kwts</option>
				</select>
				<br>
				<br>

				<h4>Potencia instalada</h4>
				<label for="potenciai"></label>
				<select id="potenciai" name="potencial">
					<option value="" selected="selected"><?php echo $potenciainst;  ?></option>
					<option value="1.5"> 1.5 kwts</option>
					<option value="2.5"> 2.5 kwts</option>
					<option value="5.5"> 5.5 kwts</option>
				</select>
				<br><br><br><br>
				<button>Enviar</button>
			</form>
		</div>
	</body>
</html>
				    		

				    	<?php

					}

				
			}
        
    }
    }			
?>