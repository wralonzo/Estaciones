<?php
	$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);;

	$equipo="SELECT * FROM equipo order by marca";
	$resequipo=$conexion->query($equipo);
	$buscar = $_POST['txtBuscar'];
	echo "<h1>Busqueda de equipos</h1>";
		?>
					<!DOCTYPE html>
					    <html>
					    		<head>
					    			<title></title>
					    			<link rel="stylesheet" type="text/css" href="../Vistas/css/table.css"/>
					    		</head>
					    		<body>					    		
					    	<section>					    			
					    			<button class="button button6" onclick="window.location='http://localhost/proyectosumg/Estaciones/Vistas/equipo.php'">Volver</button>	<br><br>
					    			<form action="../Controladores/eliminarEquipo.php" method="POST">
					    		<table class= "table" border="3" >
									<tr>
										<th>Marca</th>
										<th>Serie</th>
										<th>Tipo</th>
										<th>#Oper</th>
										<th>Marca</th>
										<th>Serie</th>
										<th>Tipo</th>
										<th>#Oper</th>
										<th>Pro_Fase</th>
										<th>Pro_Curva</th>
										<th>Cur_Fase</th>
										<th>Cur_Neutro</th>
										<th>Eliminar</th>
										<th>Modificar</th>
										<th>registrar</th>
									<tr>

	<?php	
	while ($registroempleado = $resequipo->fetch_array(MYSQLI_BOTH))
				{
					 $brand=$registroempleado[1];
					 

					
					if($brand === $buscar) {

						echo '<tr>
							<td>'.$registroempleado['marca'].'</td>
							<td>'.$registroempleado['seriecotrol'].'</td>
							<td>'.$registroempleado['tipocontrol'].'</td>
							<td>'.$registroempleado['marcacuba'].'</td>
							<td>'.$registroempleado['seriecuba'].'</td>
							<td>'.$registroempleado['tipocuba'].'</td>
							<td>'.$registroempleado['noperaciones'].'</td>
							<td>'.$registroempleado['nopercuba'].'</td>
							<td>'.$registroempleado['protfase'].'</td>
							<td>'.$registroempleado['protnuetro'].'</td>
							<td>'.$registroempleado['curvafase'].'</td>
							<td>'.$registroempleado['curvaneutro'].'</td>
							<td><input type="checkbox" name="eliminar[]" value="'.$registroempleado['id'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registroempleado['id'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
						</tr>';


					}
						


			    
				}
			echo "</form></table> </section>";



			    
			 
			





?>