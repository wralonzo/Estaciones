<?php
$conexion = mysql_connect("localhost" , "root" , "");

    if (!$conexion) {
        echo 'error';
    }
    mysql_select_db("subestaciones",$conexion);

    $id1=$_POST['id'];
    $id=$_POST['codigo'];
	$nombre=$_POST['nombre'];
	$tipo=$_POST['tipo'];
	$ubicacion=$_POST['ubicacion'];
	$tension=$_POST['tension'];
	//hacemos la sentencia sql
	//$sql = "UPDATE subestacion set nombre='$nombre', ubicacion='$ubicacion', entrada='$entrada', salida='$salida', potencia='$potenciainst' WHERE codigo='$id' ";

	$sql = "UPDATE salida set codigo='$id', nombre='$nombre', tipo='$tipo', ubicacion='$ubicacion', tension='$tension' WHERE id='$id1' ";
	$ejecutar = mysql_query($sql, $conexion);

	header("Location: http://localhost/proyectosumg/Estaciones/vistas/salida.php");


?>