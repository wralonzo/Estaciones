<?php
$conexion = mysql_connect("localhost" , "root" , "");

    if (!$conexion) {
        echo 'error';
    }
    mysql_select_db("subestaciones",$conexion);

   	$id = $_POST['id'];
	$brand=$_POST['marca_control'];
	$control_series=$_POST['serie_control'];
	$control_type=$_POST['tipo_control'];
	$brand_cuba=$_POST['marca_cuba'];
	$cuba_series=$_POST['serie_cuba'];
	$cuba_tipo=$_POST['tipo_cuba'];
	$number_operations=$_POST['numero_control'];
	$number_operations_cuba=$_POST['numero_cuba'];
	$phase_protection=$_POST['protexion_fase'];
	$neutral_progection=$_POST['protexion_neutro'];
	$phase_cuve=$_POST['fase'];
	$neutral_curve=$_POST['neutro'];
	//hacemos la sentencia sql

	$sql = "UPDATE equipo set marca='$brand', seriecotrol='$control_series', tipocontrol='$control_type', marcacuba='$brand_cuba', seriecuba='$cuba_series', tipocuba='$cuba_tipo', noperaciones='$number_operations', nopercuba='$number_operations_cuba', protfase='$phase_protection', protnuetro='$neutral_progection', curvafase='$phase_cuve', curvaneutro='$neutral_curve'  WHERE id='$id' ";



	//$sql = "UPDATE equipo set marca='$brand', seriecotrol='$control_series', tipocontrol='$control_type', marcacuba='$brand_cuba', seriecuba='$cuba_series', tipocuba='$cuba_tipo', noperaciones='$number_operations', nopercuba='$number_operations_cuba', protfase='$phase_protection', protnuetro='$neutral_progection', curvafase='$phase_cuve', curvaneutro='$neutral_curve' WHERE id='$id' ";

	$ejecutar=mysql_query($sql,$conexion);
	if (!$ejecutar) {
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/equipo.php");
	}

	else{
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/equipo.php");
	
	}
	



?>