<?php
	$host="localhost";
$usuario="root";
$contraseña="";
$base="subestaciones";
$conexion = new mysqli($host, $usuario, $contraseña, $base);;

	$equipo="SELECT * FROM salida order by id";
	$ressub=$conexion->query($equipo);
	$buscar = $_POST['txtBuscar'];
	echo "<h1>Busqueda de SubEstaciones</h1>";
		?>
					<!DOCTYPE html>
					    <html>
					    		<head>
					    			<title></title>
					    			<link rel="stylesheet" type="text/css" href="../Vistas/css/table.css"/>
					    		</head>
					    		<body>					    		
					    	<section>					    			
					    			<button class="button button6" onclick="window.location='http://localhost/proyectosumg/Estaciones/Vistas/salida.php'">Volver</button>	<br><br>
					    			<form action="../Controladores/eliminarSalida.php" method="POST">
					    		<table class= "table" border="3" >
				
									<tr>
										<th>ID</th>
										<th>Nombre</th>
										<th>Tipo</th>
										<th>Ubicacion</th>
										<th>Tension</th>
										<th>Eliminar</th>
										<th>Modificar</th>
										<th>Registrar</th>
									</tr>
	<?php	
	while ($registrosalida = $ressub->fetch_array(MYSQLI_BOTH))
				{
					 $codigo=$registrosalida[0];
					 

					
					if($codigo === $buscar) {

						echo '<tr>
							<td>'.$registrosalida['codigo'].'</td>
							<td>'.$registrosalida['nombre'].'</td>
							<td>'.$registrosalida['tipo'].'</td>
							<td>'.$registrosalida['ubicacion'].'</td>
							<td>'.$registrosalida['tension'].'</td>
							<td><input type="checkbox" name="eliminar[]" value="'.$registrosalida['id'].'"/></td>
								<td><input type="checkbox" name="modificar[]" value="'.$registrosalida['id'].'"/></td>
								<td><button class="button button4">Registrar</button></td>
								</tr';


					}
						


			    
				}
			echo "</form></table> </section>";



			    
			 
			





?>