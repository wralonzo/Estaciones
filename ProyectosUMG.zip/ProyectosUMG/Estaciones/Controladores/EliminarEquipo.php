<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>


<?php
	$host="localhost";
	$usuario="root";
	$contraseña="";
	$base="subestaciones";
	$conexion =mysql_connect($host, $usuario, $contraseña);
	mysql_select_db($base, $conexion);

	 $consulta = mysql_query("SELECT * FROM equipo", $conexion) OR die ("No se pudo ejecutar la consulta1");


	if(isset($_POST['eliminar'])){ 

	$el = $_POST['eliminar'];

	try {
		foreach($el as $id){
					mysql_query("delete from equipo where id=".$id."",$conexion);
					header("Location: http://localhost/proyectosumg/Estaciones/vistas/equipo.php");

							
		
		}
		}
		 catch (Exception $e) {
		header("Location: http://localhost/proyectosumg/Estaciones/vistas/equipo.php");
	}
	}
	


	if(isset($_POST['modificar'])){
		$mod = $_POST['modificar'];
      //  $query = "UPDATE empleado set nombre='hola' WHERE codigo=".$_POST['modificar'];
        //echo $query;
        foreach($mod as $id){

        	while ($fila = mysql_fetch_row($consulta)) {
        		$id1 = $fila[0];
			    $brand=$fila[1];;
				$control_series=$fila[2];;
				$control_type=$fila[3];;
				$brand_cuba=$fila[4];;
				$cuba_series=$fila[5];;
				$cuba_tipo=$fila[6];;
				$number_operations=$fila[7];;
				$number_operations_cuba=$fila[8];;
				$phase_protection=$fila[9];;
				$neutral_progection=$fila[10];;
				$phase_cuve=$fila[11];;
				$neutral_curve=$fila[12];;

				    if ($id ===$id1) {
				    	
				    	?>

				    	<!DOCTYPE html>
							<html>
							<head>
								<title></title>
								<link rel="stylesheet" type="text/css" href="../Formulario/css/estilo.css"/>
							</head>
							<body>
								<div class="form">
									<form action="../controladores/modificarEquipo.php" method="POST">

										<label form="marca_control"></label>
										<input type="text" name="id" placeholder="Marca de Control" equired=""  value="<?php echo $id1;  ?>">

										<label form="marca_control"></label>
										<input type="text" name="marca_control" placeholder="Marca de Control" equired=""  value="<?php echo $brand;  ?>">
										
										<label form="serie_control"></label>
										<input type="text" name="serie_control" placeholder="Serie de Control" equired="" value="<?php echo $control_series;  ?>">
										
										<label form="tipo_control"></label>
										<input type="text" name="tipo_control" placeholder="Tipo de Control" equired="" value="<?php echo $control_type;  ?>">
										
										<label form="numero_control"></label>
										<input type="text" name="numero_control" placeholder="Numero de operaciones" equired="" value="<?php echo $brand_cuba;  ?>">
										
										<p>Cuba</p>
										<label form="marca_cuba"></label>										
										<input type="text" name="marca_cuba" placeholder="Marca de Cuba" equired="" value="<?php echo $cuba_series;  ?>">
										
										<label form="serie_cuba"></label>
										<input type="text" name="serie_cuba" placeholder="Serie de Cuba" equired="" value="<?php echo $cuba_series;  ?>">
										
										<label form="tipo _cuba"></label>
										<input type="text" name="tipo_cuba" placeholder="Tipo de Cuba" equired="" value="<?php echo $cuba_tipo;  ?>">
										
										<label form="numero_cuba"></label>
										<input type="number" name="numero_cuba" placeholder="Numero de operaciones" equired="" value="<?php echo $number_operations;  ?>">
										
										<label form="protexion_neutro"></label>
										<input type="text" name="protexion_neutro" placeholder="Potreccion Neutro" equired="" value="<?php echo $phase_protection;  ?>">
										
										<label form="protexion_fase"></label>
										<input type="text" name="protexion_fase" placeholder="Proteccion Fase" equired=""  value="<?php echo $neutral_progection;  ?>">
										
										<label form="fase"></label>
										<input type="text" name="fase" placeholder="Curva fase" equired="" value="<?php echo $phase_cuve;  ?>">
										
										<label form="neutro"></label>
										<input type="text" name="neutro" placeholder="Curva Neutro" equired="" value="<?php echo $neutral_curve;  ?>">
										<button>Enviar</button>
									</form>
								</div>						

							</body>
							</html>
				    		

				    	<?php

					}

				
			}
        
    }
    }			
?>